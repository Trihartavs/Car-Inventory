﻿Option Strict On

''' <summary>
''' Author Name:    Tristan Astbury
''' Project Name:   Car Inventory
''' Date:           15-March-2019
''' Description     Application to keep a list of cars and a little information that describes their importance.
''' </summary>

Public Class CarInventoryForm
    Private carList As New SortedList
    Private currentCarIdentificationValue As String = String.Empty
    Private editMode As Boolean = False


    Private Sub Reset()

        cbNew.Checked = False
        tbModel.Text = String.Empty
        tbPrice.Text = String.Empty
        cmbMake.SelectedIndex = -1
        cmbYear.SelectedIndex = -1
        lvwCars.Text = String.Empty

    End Sub

    Private Function IsValidInput() As Boolean

        Dim returnValue As Boolean = True
        Dim outputMesssage As String = String.Empty

        If cmbMake.SelectedIndex = -1 Then
            outputMesssage += "Please select the make of the car."
            returnValue = False
        End If

        If cmbYear.SelectedIndex = -1 Then
            outputMesssage += "Please select the year the car was made."
            returnValue = False
        End If

        If tbModel.Text.Trim.Length = 0 Then
            outputMesssage += "Please enter the model of the car."
            returnValue = False
        End If

        If tbPrice.Text.Trim.Length = 0 Then
            outputMesssage += "Please enter the price of the car you've entered."
            returnValue = False
        End If
        Return returnValue

    End Function
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Dim car As cars
        Dim carItem As ListViewItem

        If IsValidInput() = True Then
            editMode = True
            lbResults.Text = "It Worked!"

            If currentCarIdentificationValue.Trim.Length = 0 Then
                car = New cars(cmbMake.Text, cmbYear.Text, tbModel.Text, tbPrice.Text, cbNew.Checked)
                carList.Add(car.IdentificationNumber.ToString(), car)
            Else
                car = CType(carList.Item(currentCarIdentificationValue), cars)

                car.Make = cmbMake.Text
                car.Model = tbModel.Text
                car.Price = tbPrice.Text
                car.Year = cmbYear.Text
                car.News = cbNew.Checked
            End If

            lvwCars.Items.Clear()

            For Each carEntry As DictionaryEntry In carList
                carItem = New ListViewItem()
                car = CType(carEntry.Value, cars)

                carItem.Checked = car.News
                carItem.SubItems.Add(car.IdentificationNumber.ToString())
                carItem.SubItems.Add(car.Make)
                carItem.SubItems.Add(car.Year)
                carItem.SubItems.Add(car.Price)

                lvwCars.Items.Add(carItem)

            Next carEntry
            Reset()
            editMode = False

        End If

    End Sub

    Private Sub lvwCars_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwCars.SelectedIndexChanged

        Const identificationSubItemIndex As Integer = 1

        currentCarIdentificationValue = lvwCars.Items(lvwCars.FocusedItem.Index).SubItems(identificationSubItemIndex).Text

        Dim car As cars = CType(carList.Item(currentCarIdentificationValue), cars)
        tbModel.Text = car.Model
        tbPrice.Text = car.Price
        cmbMake.Text = car.Make
        cmbYear.Text = car.Year
        cbNew.Checked = car.News

        lbResults.Text = car.GetCarInfo()


    End Sub
End Class


